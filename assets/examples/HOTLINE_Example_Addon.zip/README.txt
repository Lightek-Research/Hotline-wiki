HOTLINE 0.14.0+ / Pyro example

Import Pyro.rbxmx and put its ModuleScript in ServerScriptService.Hotline.Addons.
Create Workspace.Fire with configured ParticleEmitter effects (initially disabled).
Create Workspace.PyroButton with a ClickDetector. Disable the old button Script.
Restart Play. Only HOTLINE-whitelisted players may use the button.
Left-click enables effects; right-click disables them. Record both actions in Timed.
Capture records the first action only. Stop disables emitters.
Pyro.luau is the same source; do not install duplicate modules.
Full RU/EN guide: creating-addons.html.
